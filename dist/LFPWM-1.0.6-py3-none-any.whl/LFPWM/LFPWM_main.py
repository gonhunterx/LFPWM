from LFPWM.sql_db import create_tables


def main():
    create_tables()


if __name__ == "__main__":
    main()
