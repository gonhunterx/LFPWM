# LFPWM

If you are using it for the first time you have to create a user data table and then run main.
Developed in: VSCode

Step 1: pip install LFPWM

Step 2: In a terminal window run "python LFPWM_main.py"

